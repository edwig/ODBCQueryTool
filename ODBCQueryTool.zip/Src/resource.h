#include "resource1.h"
#include "resource2.h"
#include "OpenEditor.rh"
