:FILE OPEN 'c:\tmp\testoutput.txt';
:FILE print 'ODBC Test output';
:rebind rest;
:FILE CLOSE;
