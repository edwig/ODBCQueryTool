export VAR2=$VAR0/$VAR1

if [ ${#ans} -gt 2 ]; then
    # This is a comment, the above line NOT
    echo "String too long"
fi