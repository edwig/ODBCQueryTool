#include /*test*/ "stdafx.h"
#include /*test*/ <fstream>
#include //<COMMON/AppGlobal.h>
#include <COMMON/ExceptionHelper.h>
#include //"OpenEditor/OEDocument.h"
