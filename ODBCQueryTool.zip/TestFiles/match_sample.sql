declare
  function ... is
      procedure ... is
          function ... is
          begin-- defer + close the prev deferred construction
              loop-- defer
              end loop;
          end;
      begin -- defer 
      end;
  begin -- defer
  end;
begin
  loop
      loop
          for loop
          end loop;
      end loop;
  end loop;
  
  begin
    declare
    begin
    end;
  end;
end;
/

declare
begin
  loop
  end loop;
  begin
  end;
end;
/

if (( 1 < 2 ) or ( 2 < 3 )) then
  if ( 4 < 5 ) then
    loop
    exit
    end loop;
  elsif () then
    null;
  else
    for in loop
      if ( 6 < 7 ) then
      elsif ( 8 < 9 ) then
      end if;
    end loop;
  end if;
end if;
/

declare
  procedure is
  begin
  end;
begin
    begin
        --end
        raise_application_error(-20999, 'test');
        /*end*/
        /*
        end
        */
    exception
    end;
    
    if then
    end if;

    declare
    begin
    exception
    end;
end;

if then
end if;